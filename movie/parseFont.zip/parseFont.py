from fontTools.ttLib import TTFont
import numpy as np
import operator
from font.m_config import labels
import os


def coordinate():

    # 样本数据
    coordinate_list1 = []

    for font in os.listdir('./font'):
        if font[:5] == 'local':
            local_font = TTFont('./font/' + font)
            local_list = local_font.getGlyphOrder()[2:]
            for uniname in local_list:
                coordinate = local_font['glyf'][uniname].coordinates
                coordinate_list1.append(sum([list(i) for i in coordinate[:12]], []))


    # 解析数据
    new_font = TTFont('./font/new.woff')
    # new_font.saveXML('./static/new_font.xml')
    new_list = new_font.getGlyphOrder()[2:]

    coordinate_list2 = []
    for uniname in new_list:
        coordinate = new_font['glyf'][uniname].coordinates
        coordinate_list2.append(sum([list(i) for i in coordinate[:12]], []))

    return coordinate_list1, coordinate_list2, new_list


def createDataSet(data):
    group = np.array(data)
    return group


def classify0(inX, dataSet, labels, k):
    """
    :param inX: 用于分类的输入向量
    :param dataSet: 输入的训练样本季
    :param labels: 样本数据的类标签向量
    :param k: 用于选择最邻近邻居的数目
    :return: 邻近结果
    """

    # 获取样本数据数量
    dataSetSize = dataSet.shape[0]

    # 矩阵运算，计算测试数据与每个样本数据对应数据项的差值
    diffMat = np.tile(inX, (dataSetSize, 1)) - dataSet


    # 上一步骤结果平方和
    sqDiffMat = diffMat**2
    sqDistances = sqDiffMat.sum(axis=1)

    # 取平方更，得到距离向量
    distances = sqDistances**0.5

    # 按照距离从低到高排序
    sortedDistIndicies = distances.argsort()
    classCount = {}

    # 依次取出最近样本数据
    for i in range(k):
        # 记录该样本数据所属类别
        voteIlabel = labels[sortedDistIndicies[i]]
        classCount[voteIlabel] = classCount.get(voteIlabel, 0) + 1

    # 对类别出现的频次进行排序，从高到低
    sortedDistIndicies = sorted(
        classCount.items(), key=operator.itemgetter(1), reverse=True)

    # 返回出现频次最高的类别
    return sortedDistIndicies[0][0]


def parseFontList():
    coordinate_list1, coordinate_list2, new_list = coordinate()
    group = createDataSet(coordinate_list1)
    parse_list = []
    for i in coordinate_list2:
        parse_list.append(classify0(i, group, labels, 2))

    new_list = [i.lower().replace('uni', r'&#x') + ';' for i in new_list]
    parse_list = dict(zip(new_list, parse_list))
    return parse_list

